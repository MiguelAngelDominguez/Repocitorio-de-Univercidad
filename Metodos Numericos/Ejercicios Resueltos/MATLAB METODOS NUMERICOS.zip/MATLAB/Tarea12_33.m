%Capitulo 12 _Tarea 12_33.Estudio de Casos:Ecuaciones algebraicas lineales
%Cantidad de componentes  producida por dia
disp('Matriz A:')
A=[150 -50 0 0;-50 130 -80 0;0 -80 280 -200;0 0 -200 200 ];
disp(A);
disp('Valor de B:')
B=[0;0;0;14715];
disp(B);
disp('Resultado:')
inv(A)*B