%Capitulo 12 _Tarea 12_13.Estudio de Casos:Ecuaciones algebraicas lineales
%Metros cubicos a extraer
disp('Matriz A:')
A=[0.55 0.25 0.25;0.30 0.45 0.20;0.15 0.30 0.55];
a=[55 25 25;30 45 20;15 30 55];
disp(A);
disp('Valor de B:')
B=[4800;5800;5700];
disp(B);
disp('Resultado:')
inv(a)*B