%ESTE ES MI PRIMER SCRIPT!!!!!!!!!
a=5
b=4
c=7;
f=a+b+c
