%Capitulo 12 _Tarea 12_34.Estudio de Casos:Ecuaciones algebraicas lineales
%Cantidad de componentes  producida por dia
disp('Matriz A:')
A=[100 1 0;50 -1 1;25 0 -1 ];
disp(A);
disp('Valor de B:')
B=[519.72;216.55;108.27];
disp(B);
disp('Resultado:')
inv(A)*B